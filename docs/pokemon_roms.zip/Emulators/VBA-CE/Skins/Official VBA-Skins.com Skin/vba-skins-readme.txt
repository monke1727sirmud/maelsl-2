Vba-Skins.com, A skin for VBA

INSTALL INSTRUCTIONS:

Unzip into any directory, preferably its own, as long as all files are together.
In VBA go Options - Video - Render Method - Select Skin...
Choose the appropriate .INI file.

Nothing much to say really. Everyone at GBAtemp (www.gbatemp.net) rocks.

Oh and dont modify the skin files.
Or distribute without all the files together.

Created by Mole_Incarnate,

Distributed at GBAtemp, through my own webspace at www.iinet.net.au/~nfrancis

Vba-Skins.com is the premier site for all things skins, with VBA!