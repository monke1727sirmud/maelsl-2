-----------------------------------------------
skin created by shaunj66 (shaunj66@gbatemp.net)

for VisualBoyAdvance 1.5 or higher
-----------------------------------------------
How to use:

Just extract the contents of this zip to any
directory (keep it with VBA for easiness!),
then open up VisualBoyAdvance, and select the
Options menu, then Video menu, then Render
Method, and then choose Select Skin and locate
the directory where you extracted the skin and
choose and open the extracted INI file.
VisualBoyAdvance should now have switched to
skin mode, and the selected skin!
-----------------------------------------------
Problems?:

VisualBoyAdvance 1.5 skinning doesn't seem to
work on Windows 95/98/ME/2000. Do not contact
me if you are experiencing this problem, it's
a known problem by the author of VBA and he's
currently working on a solution. Keep up to
date on the current developments at his
website here:

http://vboy.emuhq.com

If you have any other problems, questions or
comments about my skins, feel free to e-mail
me at shaunj66@gbatemp.net
-----------------------------------------------
Thanks to:

Forgotten and his team for creating such a
wonderful emulator!

solarsaturn9 for his support and additional
colour variations of my skins.
-----------------------------------------------
                                www.gbatemp.net
-----------------------------------------------