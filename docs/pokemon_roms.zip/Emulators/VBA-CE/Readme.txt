Visualboy Advance-CE 1.0


August 16th 2004

   Made a few changes but not many, first one is better support for skins, infact this pack 
   should include a good amount of VBA skins to start you out. Updated the icons and GUI a
  bit, aswell as tweak out some speed increases, but not many. Mostly this update makes it 
  look less dated.


   -hiroshi