THE POKEMON ROM PACK 2 2008

***********************************************************************************************
                                          README/FAQ
***********************************************************************************************

ROMS:
*****
GB:

Pokemon Blue
Pokemon Red
Pokemon Yellow
Pokemon Gold
Pokemon Silver
Pokemon Crystal
Pokemon pinball
Pokemon tradeing card game
Pokemon Puzzle challenge


GBA:

Pokemon Firered
Pokemon Leafgreen
Pokemon Sapphire
Pokemon Ruby
Pokemon Emerald
Pok�mon Pinball - Ruby & Sapphire

***********************************************************************************************
also two emulators are included: TGB Dual and visual boy advance


TGB Dual 7:
this emulator supports the link function on one PC!! so you can trade the pokemon
it also supports internet play as well BUT it only runs Game boy games not gameboyadvance.

VBA: (visual boy advance)
this the best if not THE best GBA\GB emulator around it supports both file types (GB\GBA)
and has a costomisable color pallett and many other functions

VBA-CE:
are faster version of vba.
new icon and menu.

VBA link:
just vba with link support.
*note* in the menu change the link time out if it doesent link

also the save files are compatable with each other (use one to link and the other to play)


***********************************************************************************************
OTHER:
in this folder you will find hacks and other language versions of the GBC roms.



included is the Winrar archiver to open the 7z files (trial version valid for 40 Days)
BUT can be used for ever. with just one popup box to close and no wait time!!!

***********************************************************************************************

FAQ:
****

Q:When i start pokemon sapphire/Ruby i only get a white screen on start up?
A:in vba the save type needs to be set to flash128k to do this go
options>Emulator>Savetype>flash128k NO PATCH IS NEEDED!!!!!!!!!

Q:in pokemon Firered/leafgrn i get the error message "the 1mb curcit borad is not installed"?
A:again in vba the save type needs to be set to flash128k to do this go
options>Emulator>Savetype>flash128k NO PATCH IS NEEDED!!!!!!!!!

Q:Why does VBA have a BIOS file it doesn't need one?
A:This makes the "GAMEBOY" Screen appare at start up if you want to actavate it go
options>emulator>slect bios file      then
options>emulator>use BIOS file

***********************************************************************************************
                                     PACK 2 By 343_guiltySpark
***********************************************************************************************